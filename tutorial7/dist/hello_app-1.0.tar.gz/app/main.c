#include <stdio.h>

#include "../../tutorial7/lib/lib.h"


int main(int argc, char* argv[])
{
    const float result = add(2.0, 3.0);
    printf("result=%.2f\n", result);
    return 0;
}
