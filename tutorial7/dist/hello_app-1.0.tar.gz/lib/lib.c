#include "../../tutorial7/lib/lib.h"

#include <stdio.h>

float add(const float x, const float y)
{
    return x + y;
}
